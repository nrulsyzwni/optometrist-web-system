<?php

include('../include/dbconn.php');

$user_ID=@$_POST['user_ID']; //the @ is optional, to suppress error messages

$dateMade=@$_POST['dateMade'];

$dateApp=@$_POST['dateApp'];

$timeApp=@$_POST['timeApp'];

$sql="insert into appointment
(user_ID,dateMade,dateApp,times) values('$user_ID','$dateMade','$dateApp','$timeApp')";

$res=mysqli_query($dbconn,$sql) or die(mysqli_error($dbconn));

if ($res==1) echo "OK";

mysqli_close($dbconn);

?>