<?php
include('dbconnMobile.php');
$username=@$_POST['username'];
$password=@$_POST['password'];
echo $username;
echo $password;

$sql="SELECT * FROM userdata WHERE username='".$username."' and password='".$password."'";
$query=mysqli_query($dbconn,$sql) or die("Error: ".mysqli_error($dbconn));
$row=mysqli_num_rows($query);

if($row != 0)
{
	echo "login successfully";
}
 else 
    {
	echo "login failed";
    }
?>
