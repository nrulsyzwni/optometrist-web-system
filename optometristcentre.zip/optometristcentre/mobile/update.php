<?php
include('../include/dbconn.php');
$appID=@$_POST['appID'];

$user_ID=@$_POST['user_ID'];

$dateMade=@$_POST['dateMade'];

$dateApp=@$_POST['dateApp'];

$status=@$_POST['status'];

$times=@$_POST['times'];


$sql="update appointment set user_ID='$user_ID',dateMade='$dateMade',dateApp='$dateApp',status='$status',times='$times'
where appID='$appID'";

$res=mysqli_query($dbconn,$sql) or die(mysqli_error($dbconn));

if ($res==true) echo "OK_EDIT";

mysqli_close($dbconn);

?>