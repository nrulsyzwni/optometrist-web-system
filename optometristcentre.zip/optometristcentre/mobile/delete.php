<?php

include('../include/dbconn.php');

$appID=@$_POST['appID'];

$sql="delete from appointment where
appID='$appID'";

$res=mysqli_query($dbconn,$sql) or
die(mysqli_error($dbconn));

if ($res==1) echo "OK_DEL";

mysqli_close($dbconn);

?>