<?php

include('../include/dbconn.php');

//$appID=1; //if you want to test

$appID=@$_POST['appID'];

$sql="select * from appointment where appID='$appID'";

$res=mysqli_query($dbconn,$sql) or die(mysqli_error($dbconn));

$r=mysqli_fetch_array($res,MYSQLI_NUM);

$json[]=$r;

echo json_encode($json,JSON_UNESCAPED_UNICODE);

mysqli_free_result($res);

mysqli_close($dbconn);

?>