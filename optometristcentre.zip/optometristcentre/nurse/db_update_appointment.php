<?php
include('../include/dbconn.php');

$i=0;
$id=$_POST['id'];
foreach ( $_POST as $sForm => $value )
{
	$postedValue = htmlspecialchars( stripslashes( $value ), ENT_QUOTES ) ;
    $valuearr[$i] = $postedValue; 
$i++;
}



	  $update = "UPDATE appointment SET
				status = 'verified'
				WHERE appID='$id]'";
	  //echo $update;
	  $result = mysqli_query($dbconn, $update) or die ("Error: " . mysqli_error($dbconn));

	  if ($result) {
	  ?>
	  <script type="text/javascript">
	   window.location = "view_appointment.php"
	  </script>
	  <?php }       
      
?>