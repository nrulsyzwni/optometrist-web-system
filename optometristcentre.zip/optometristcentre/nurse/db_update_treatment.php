<?php
	include('../include/dbconn.php');
	
	$id=$_POST['id'];
	
	$update = "UPDATE treatment SET treatmentStatus='complete' WHERE treatmentID='$id'";
	$result = mysqli_query($dbconn, $update) or die ("Error: " . mysqli_error($dbconn));
	if ($result) {
	  ?>
	  <script type="text/javascript">
	  	window.location = "view_treatment2.php"
	  </script>
	  <?php }
    
    else
    {
      echo $update;
	?> 
	  <script type="text/javascript">
	  	window.location = "view_treatment2.php"
	  </script>
	<?php       
     } 
?>