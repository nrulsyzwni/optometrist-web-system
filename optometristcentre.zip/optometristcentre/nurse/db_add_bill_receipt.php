<!DOCTYPE html>
<?php 
include('../include/dbconn.php');

include ("../login/session.php");
session_start();

if (!isset($_SESSION['username'])) {
        header('Location: ../login');
		} 
                $sqlUSER= "SELECT * from userdata";
				$queryUSER = mysqli_query($dbconn, $sqlUSER) or die ("Error: " . mysqli_error());
				$rowUSER = mysqli_num_rows($queryUSER);
				$rUSER= mysqli_fetch_assoc($queryUSER);
				
                date_default_timezone_set("Asia/Kuala_Lumpur");
                $date = date("Y-m-d");
                $time = date("H:i:s");
		
?>

<head>
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=Edge">
     <meta name="description" content="">
     <meta name="keywords" content="">
     <meta name="author" content="Tooplate">
     <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- <link rel="stylesheet" href="css/bootstrap.min.css">
     <link rel="stylesheet" href="css/magnific-popup.css">

     <link rel="stylesheet" href="css/font-awesome.min.css">
     <link rel="stylesheet" href="css/animate.css">

     <link rel="stylesheet" href="css/owl.carousel.css">
     <link rel="stylesheet" href="css/owl.theme.default.min.css">

     <!-- MAIN CSS 
		<link rel="stylesheet" href="css/tooplate-style.css">-->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<style>
		body 
		{
			font-family: Arial, Helvetica, sans-serif;
			margin:0;
			background-color:DarkSeaGreen;
		}
		
		row
		{
			margin-right:15px;
			margin-left:15px;
		}
		
		.container
		{
			padding-right:15px;
			padding-left:15px;
			margin-right:auto;
			margin-left:auto;
			display:inline-block;
		}
		
		@media (min-width:768px){
		.container{
			width:750px}
			}@media (min-width:992px){
				.container{
					width:970px
					}
					}@media (min-width:1200px){
						.container
						{width:1170px
						}}
							
		.col-md-8 .col-sm-7 
		{
			 width:20%;
			 position:relative;
			 min-height:1px;
			 padding-right:15px;
			 padding-left:15px
		}
		
		 text-right
		 {
			 text-align:50px;
			 padding-right:50px;
			 padding-left:100px;
			 display:inline-block;
		 }
		 
		 header 
		{
			background: #ffffff;
			border-bottom: 1px solid #f2f2f2;
			display: block;
			height: 40px;
		}
		
	header p,
	header span {
    font-size: 12px;
    line-height: 10px;
    padding-top: 0px;
	padding-left:15px;
	padding-right:400px;
	display:inline-block;
  }
.p 
{
	font-size:16px;
	width:100%;
	padding-left:505px;
	padding-right:190px;
}

  header a,
  header span {
    color: #747474;
  }

  header span {
    font-weight: 500;
    display: inline-block;
    padding: 15px;

  }

  header span.date-icon {
    border-left: 1px solid #f2f2f2;
    border-right: 1px solid #f2f2f2;
    padding-right: 15px;
    padding-left: 15px;
	
  }

  header span i {
    color: #a5c422;
    margin-right: 15px;
  }
  
		.navbar {
  overflow: hidden;
  background-color: white;
  
}

.navbar a {
  float: left;
  font-size: 16px;
  color: black;
  text-align: center;
  padding: 10px 16px;
  text-decoration: none;
}

.dropdown {
  float: left;
  overflow: hidden;
}

.dropdown .dropbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: ;
  padding: 10px 15px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.navbar a:hover, .dropdown:hover .dropbtn {
  background-color: white;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 100px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: black;
  padding: 12px 15px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  background-color: white;
}

.dropdown:hover .dropdown-content {
  display: block;
}
	</style>
	</head>
	<body>
	<body id="top" data-spy="scroll" data-target=".navbar-collapse" data-offset="50">
     <!-- HEADER -->
     <header>
          <div class="container">
               <div class="row">					
					<div class="col-md-8 col-sm-7 text-align-right">
						<p class=="p">Welcome to eye specialist</p>
                         <span class="phone-icon"><i class="fa fa-phone"></i> 010-060-0160</span>
                         <span class="date-icon"><i class="fa fa-calendar-plus-o"></i> 6:00 AM - 10:00 PM (Mon-Fri)</span>
                         <span class="email-icon"><i class="fa fa-envelope-o"></i> <a href="#">ikonikeyespecialist@company.com</a></span>
                    </div>
               </div>
          </div>
     </header>
	 
	  <!-- MENU -->
     <section class="navbar" >
          <div class="container">

               <div class="navbar-header"
	 
                    <!-- lOGO TEXT HERE -->
                    <a href="index.html" class="navbar-brand">EYE SPECIAlIST CENTRE</a>
               </div>

               <!-- MENU LINKS -->
               <div class="collapse navbar-collapse">
                   <div class="navbar">
						<a href="#home">HOME</a>
						
						<div class="dropdown">
						<button class="dropbtn">USERS
						<i class="fa fa-caret-down"></i>
						</button>
						<div class="dropdown-content">
						<a href="../nurse/view_user.php">VIEW</a>
						<a href="update_view_user.php">UPDATE</a>
						<a href="search_patient.php">SEARCH PATIENT</a>
					</div>
				  </div> 
				  
						<div class="dropdown">
						<button class="dropbtn">SCHEDULE 
						<i class="fa fa-caret-down"></i>
						</button>
						<div class="dropdown-content">
						<a href="view_schedule.php">VIEW</a>
						<a href="update_view_schedule.php">UPDATE</a>
						<a href="add_schedule.php">ADD</a>
					</div>
				  </div> 
				  
				  <div class="dropdown">
						<button class="dropbtn">APPOINTMENT
						<i class="fa fa-caret-down"></i>
						</button>
						<div class="dropdown-content">
						<a href="view_appointment.php">VIEW</a>
						<a href="update_view_appointment.php">UPDATE</a>
						<a href="add_appointment.php">ADD</a>
					</div>
				  </div> 
				
				  
				   
				  <div class="dropdown">
						<button class="dropbtn">TREATMENT
						<i class="fa fa-caret-down"></i>
						</button>
						<div class="dropdown-content">
						<a href="view_treatment2.php">VIEW</a>
						<a href="update_view_treatment2.php">UPDATE</a>
						<a href="add_treatment2.php">ADD</a>
					</div>
				  </div> 
				  
				  <div class="dropdown">
						<button class="dropbtn">MEDICINE
						<i class="fa fa-caret-down"></i>
						</button>
						<div class="dropdown-content">
						<a href="view_medicine.php">VIEW</a>
						<a href="update_view_medicine.php">UPDATE</a>
						<a href="add_medicine.php">ADD</a>
					</div>
				  </div> 
				  
				  
				  <div class="dropdown">
						<button class="dropbtn">REPORT
						<i class="fa fa-caret-down"></i>
						</button>
						<div class="dropdown-content">
						<a href="report_user.php">REPORT USER</a>
					</div>
				  </div> 
				  
				  <a href="../login/logout.php">LOGOUT</a>
				</div>

               </div>

          </div>
     </section>
	 
	 <div class="container">

<h3></h3>

<fieldset>
          		<!--  (Recipt Code)  -->
				<?php
                            
                if(isset($_POST['submit']))
                {
					$treatmentID= ['treatmentID'];
                    $scheduleID = $_POST['patient'];
					$notice = $_POST['notice'];
					$treatmentStatus="ongoing";
				
					
					$row = $_POST['bil'];
					
                    $Tid = "Tid";
                    $Mid = "Mid";
                    $Mname = "Mname";
                    $quantity = "quantity";	
                    $mprice = "medicinePrice";
  				
                    //$order_id = 1;
					//echo $order_id;
					//echo  $pid;
                    //$o_1 = mysql_query("SELECT * FROM order_tab");
                    //$number_of_rows = mysql_num_rows($o_1);
					
					$sql= "SELECT * FROM treatment t ,treatment_medicine tm WHERE tm.treatmentID=t.treatmentID ";
					$query = mysqli_query($dbconn, $sql) or die ("Error: " . mysqli_error());
					$rows = mysqli_num_rows($query);
					//$r= mysqli_fetch_assoc($query);
					   
                    if($rows!=0)
                        {
                            $treatmentID = $rows + 1;
                        }
                                
                    echo "<form id='recipt' name='recipt' method='post' action=''>
                      <table width=\"680\" border=\"0\" align=\"center\">
                        <tr>
                          <td colspan=\"5\" align=\"center\"><b>RECEIPT</b></td>
                        </tr>
						<tr>
                          <td colspan=\"5\" align=\"center\">Optometrist Center</td>
                        </tr>
                        <tr>
                          <td colspan=\"5\" align=\"center\">Made Just For You</td>
                        </tr>
                        <tr>
                          <td colspan=\"5\"></td>
                        </tr>
                        <tr>
                          <td colspan=\"5\"></td>
                        </tr>
                        <tr>
                          <td>Transaction</td>
                          <td colspan=\"4\">: ".$treatmentID."</td>
                        </tr>
                        <tr>
                          <td>Schedule ID</td>
                          <td colspan=\"4\">: ".$scheduleID."</td>
                        </tr>
                        <tr>
                          <td>Description</td>
                          <td colspan=\"4\">: ".$notice."</td>
                        </tr>
                        <tr>
                        <tr>
                          <td colspan=\"5\"><hr /></td>
                        </tr>
                        <tr>
                          <td width=\"45\">Code</td>
                          <td width=\"1000\">Name</td>
                          <td width=\"45\">Price/Unit</td>
                          <td width=\"45\">Quantity</td>
                          <td width=\"45\">Total</td>
                        </tr>";
                        
                        $itemCount = 0;
                        $totalPrice = 0;
                        $strCash = $_POST['cash'];
                        $cash = intval($strCash);
                     
                        for($a=0;$a<$row;$a++)
                        {
                            $strMid = $_POST[''.$Mid.$a.''];
                            $strQuantity = $_POST[$quantity.$a];	
                            $strPrice = $_POST[$mprice.$a];	

							$sqlf= "SELECT * FROM medicine WHERE medicineID = '$strMid'";
							$queryf = mysqli_query($dbconn, $sqlf) or die ("Error: " . mysqli_error());
							$rowf = mysqli_num_rows($queryf);
							$rf= mysqli_fetch_assoc($queryf);
					
							$sMid = $rf['medicineID'];
							
                            //buat pengiraan utk total setiap line dan quantity
                            if($strQuantity > 0)
                            {
                               $sqlordersdetail = "INSERT INTO treatment_medicine (treatmentID, medicineID, qty) 
												   VALUES('".$treatmentID."', '".$sMid."', '".$strQuantity."')";
                                mysqli_query($dbconn,$sqlordersdetail  ) or die ("Error: " . mysqli_error());
                                $strTotal = ($strPrice * intval($strQuantity));
                                
                                echo "<tr>
                                  <td>".$sMid."</td>
                                  <td>".$rf['medicineName']."</td>
                                  <td>".$strPrice."</td>
                                  <td>".$strQuantity."</td>
                                  <td>".$strTotal."</td>
                                </tr>";
                                $itemCount = $itemCount + intval($strQuantity);
                                $totalPrice = $totalPrice + (intval($strQuantity) * $strPrice);
                            }
                        }
                        
                        $sql = "INSERT INTO treatment(treatmentID,scheduleID, notice,treatmentStatus) 
									 VALUES('".$treatmentID."','".$scheduleID."', '".$notice."', '".$treatmentStatus."')";
                        mysqli_query($dbconn,$sql ) or die ("Error: " . mysqli_error($dbconn));
                        $change = intval($cash) - intval($totalPrice);
                
                        echo"
                        <tr>
                          <td colspan=\"5\"><hr /></td>
                        </tr>
                        <tr>
                          <td colspan=\"4\">Item Count</td>
                          <td colspan=\"1\" align=\"right\">".$itemCount."</td>
                        </tr>
                        <tr>
                          <td colspan=\"4\">Grand Total</td>
                          <td colspan=\"1\" align=\"right\">".$totalPrice."</td>
                        </tr>
                        <tr>
                          <td colspan=\"4\">Cash</td>
                          <td colspan=\"1\" align=\"right\">".$cash."</td>
                        </tr>
                            <tr>
                          <td colspan=\"5\"><hr /></td>
                        </tr>
                        <tr>
                          <td colspan=\"4\">Change</td>
                          <td colspan=\"1\" align=\"right\">".$change."</td>
                        </tr>
                        <tr>
                          <td colspan=\"5\"><hr /></td>
                        </tr>
                        <tr>
                          <td colspan=\"5\" align=\"center\">Thank You</td>
                        </tr>
                        <tr>
                          <td colspan=\"5\" align=\"center\">Plese Come Again</td>
                        </tr>
                      </table>
                    </form>";
                }
      ?>
    </fieldset> 
</div>
</body>
</html>