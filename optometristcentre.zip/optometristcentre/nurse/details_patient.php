<?php 
// Include database connection settings
include('../include/dbconn.php');
include ("../login/session.php");
session_start();
$user = $_SESSION['username'];
if (!isset($_SESSION['username'])) {
        header('Location: ../login');
		} 
	$user_ID = $_GET['user_ID'];
?>

<head>
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=Edge">
     <meta name="description" content="">
     <meta name="keywords" content="">
     <meta name="author" content="Tooplate">
     <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- <link rel="stylesheet" href="css/bootstrap.min.css">
     <link rel="stylesheet" href="css/magnific-popup.css">

     <link rel="stylesheet" href="css/font-awesome.min.css">
     <link rel="stylesheet" href="css/animate.css">

     <link rel="stylesheet" href="css/owl.carousel.css">
     <link rel="stylesheet" href="css/owl.theme.default.min.css">

     <!-- MAIN CSS 
		<link rel="stylesheet" href="css/tooplate-style.css">-->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<style>
		body 
		{
			font-family: Arial, Helvetica, sans-serif;
			margin:0;
			background-color:DarkSeaGreen;
		}
		
		row
		{
			margin-right:15px;
			margin-left:15px;
		}
		
		.container
		{
			padding-right:15px;
			padding-left:15px;
			margin-right:auto;
			margin-left:auto;
			display:inline-block;
		}
		
		@media (min-width:768px){
		.container{
			width:750px}
			}@media (min-width:992px){
				.container{
					width:970px
					}
					}@media (min-width:1200px){
						.container
						{width:1170px
						}}
							
		.col-md-8 .col-sm-7 
		{
			 width:20%;
			 position:relative;
			 min-height:1px;
			 padding-right:15px;
			 padding-left:15px
		}
		
		 text-right
		 {
			 text-align:50px;
			 padding-right:50px;
			 padding-left:100px;
			 display:inline-block;
		 }
		 
		 header 
		{
			background: #ffffff;
			border-bottom: 1px solid #f2f2f2;
			display: block;
			height: 40px;
		}
		
	header p,
	header span {
    font-size: 12px;
    line-height: 10px;
    padding-top: 0px;
	padding-left:15px;
	padding-right:400px;
	display:inline-block;
  }
.p 
{
	font-size:16px;
	width:100%;
	padding-left:505px;
	padding-right:190px;
}

  header a,
  header span {
    color: #747474;
  }

  header span {
    font-weight: 500;
    display: inline-block;
    padding: 15px;

  }

  header span.date-icon {
    border-left: 1px solid #f2f2f2;
    border-right: 1px solid #f2f2f2;
    padding-right: 15px;
    padding-left: 15px;
	
  }

  header span i {
    color: #a5c422;
    margin-right: 15px;
  }
  
		.navbar {
  overflow: hidden;
  background-color: white;
  
}

.navbar a {
  float: left;
  font-size: 16px;
  color: black;
  text-align: center;
  padding: 10px 16px;
  text-decoration: none;
}

.dropdown {
  float: left;
  overflow: hidden;
}

.dropdown .dropbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: ;
  padding: 10px 15px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.navbar a:hover, .dropdown:hover .dropbtn {
  background-color: white;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 100px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: black;
  padding: 12px 15px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  background-color: white;
}

.dropdown:hover .dropdown-content {
  display: block;
}
	</style>
	</head>
	<body>
	<body id="top" data-spy="scroll" data-target=".navbar-collapse" data-offset="50">
     <!-- HEADER -->
     <header>
          <div class="container">
               <div class="row">					
					<div class="col-md-8 col-sm-7 text-align-right">
						<p class=="p">Welcome to eye specialist</p>
                         <span class="phone-icon"><i class="fa fa-phone"></i> 010-060-0160</span>
                         <span class="date-icon"><i class="fa fa-calendar-plus-o"></i> 6:00 AM - 10:00 PM (Mon-Fri)</span>
                         <span class="email-icon"><i class="fa fa-envelope-o"></i> <a href="#">ikonikeyespecialist@company.com</a></span>
                    </div>
               </div>
          </div>
     </header>
	 
	  <!-- MENU -->
     <section class="navbar" >
          <div class="container">

               <div class="navbar-header"
	 
                    <!-- lOGO TEXT HERE -->
                    <a href="index.html" class="navbar-brand">EYE SPECIAlIST CENTRE</a>
               </div>

               <!-- MENU LINKS -->
               <div class="collapse navbar-collapse">
                   <div class="navbar">
						<a href="#home">HOME</a>
						
						<div class="dropdown">
						<button class="dropbtn">USERS
						<i class="fa fa-caret-down"></i>
						</button>
						<div class="dropdown-content">
						<a href="../nurse/view_user.php">VIEW</a>
						<a href="update_view_user.php">UPDATE</a>
						<a href="search_patient.php">SEARCH PATIENT</a>
					</div>
				  </div> 
				  
						<div class="dropdown">
						<button class="dropbtn">SCHEDULE 
						<i class="fa fa-caret-down"></i>
						</button>
						<div class="dropdown-content">
						<a href="view_schedule.php">VIEW</a>
						<a href="update_view_schedule.php">UPDATE</a>
						<a href="add_schedule.php">ADD</a>
					</div>
				  </div> 
				  
				  <div class="dropdown">
						<button class="dropbtn">APPOINTMENT
						<i class="fa fa-caret-down"></i>
						</button>
						<div class="dropdown-content">
						<a href="view_appointment.php">VIEW</a>
						<a href="update_view_appointment.php">UPDATE</a>
						<a href="add_appointment.php">ADD</a>
					</div>
				  </div> 
				
				  
				    
				  <div class="dropdown">
						<button class="dropbtn">TREATMENT
						<i class="fa fa-caret-down"></i>
						</button>
						<div class="dropdown-content">
						<a href="view_treatment2.php">VIEW</a>
						<a href="update_view_treatment2.php">UPDATE</a>
						<a href="add_treatment2.php">ADD</a>
					</div>
				  </div> 
				  
				  <div class="dropdown">
						<button class="dropbtn">MEDICINE
						<i class="fa fa-caret-down"></i>
						</button>
						<div class="dropdown-content">
						<a href="view_medicine.php">VIEW</a>
						<a href="update_view_medicine.php">UPDATE</a>
						<a href="add_medicine.php">ADD</a>
					</div>
				  </div> 
				  
				  
				  <div class="dropdown">
						<button class="dropbtn">REPORT
						<i class="fa fa-caret-down"></i>
						</button>
						<div class="dropdown-content">
						<a href="report_user.php">REPORT USER</a>
					</div>
				  </div> 
				  
				  <a href="../login/logout.php">LOGOUT</a>
				</div>

               </div>

          </div>
     </section>
	 
	 <div class="container">

<center><h3>PATIENT DETAIL </h3></center>

<?php
	$query = "SELECT * FROM userdata WHERE user_ID='$user_ID'";
	$result = mysqli_query($dbconn, $query) or die ("Error: " . mysqli_error($dbconn));
	$row = mysqli_fetch_array($result);
?>

<fieldset>

<form name="edit_user" method="post" action="db_update_user.php" enctype="multipart/form-data">
    <table width="80%" height="50%"border="0" align="center">
      <tr>
        <td width="16%">Name</td>  
        <td width="84%"><?php echo ucwords (strtolower($row['name'])); ?></td>  
      </tr>  
      <tr> 
        <td width="16%">Gender</td>
        <td>
        <input name="gender" type="radio" value="1" <?php if($row['gender']==1) { echo 'checked'; } ?> />Men
		<input name="gender" type="radio" value="2" <?php if($row['gender']==2) { echo 'checked'; } ?>/>Women
        </td>
      </tr>
	  <tr>
        <td width="16%">Email</td>
        <td><?php echo $row['email']; ?></td>
      </tr>
	  <tr>
        <td width="16%">Phone No</td>
        <td><?php echo $row['telephone']; ?></td>
      </tr>
      <tr>
        <td width="16%">Address</td>
        <td><?php echo ucwords (strtolower($row['address'])); ?></td>
      </tr>
      <tr>
        <td width="16%">Username</td>
        <td><?php echo $row['username']; ?>
        	<input type="hidden" name="username" size="50" value="<?php echo $row['username']; ?>" /></td> 
      </tr>
      <tr>
        <td width="16%">Password</td>
        <td><?php echo $row['password']; ?></td> 
      </tr>

      <tr> 
        <td colspan="2"><input type="button" name="cancel" value="Back " onclick="location.href='view_user.php'" /></td>
      </tr>
	  
    </table>
</form>

</fieldset>
 
</div>
   
</body>
</html>