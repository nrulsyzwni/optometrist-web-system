<?php
	include('../include/dbconn.php');
	
	$scheduleID=$_GET['scheduleID'];
	
	$delete = "DELETE FROM schedule WHERE scheduleID='$scheduleID'";
	$result = mysqli_query($dbconn, $delete) or die ("Error: " . mysqli_error($dbconn));
	//echo $delete;
	
	if ($result) {
	  ?>
	  <script type="text/javascript">
	  	window.location = "view_schedule.php"
	  </script>
	  <?php }
    
    else
    {
      echo $update;
	?> 
	  <script type="text/javascript">
	  	window.location = "view_schedule.php"
	  </script>
	<?php       
     } 
	
?>