<?php
include('../include/dbconn.php');

$i=0;

foreach ( $_POST as $sForm => $value )
{
	$postedValue = htmlspecialchars( stripslashes( $value ), ENT_QUOTES ) ;
    $valuearr[$i] = $postedValue; 
$i++;
}date_default_timezone_set("Asia/Kuala_Lumpur");
                $date = date("Y-m-d");
                $time = date("H:i:s");
				
				
                 
                if(isset($_POST['submit']))
                {
					//$appID = $_POST['appID'];
					$dateA = $_POST['dateA'];
	  
  

	 $update = "UPDATE appointment SET
				dateApp='".$dateA."'
				WHERE  appID='$valuearr[0]'
				" ; 
	$update1 = "UPDATE schedule SET 
				date='".$dateA."'
			    WHERE  appID='$valuearr[0]'
				" ; 
	  //echo $update;
	  $result = mysqli_query($dbconn, $update) or die ("Error: " . mysqli_error($dbconn));
	   $result1 = mysqli_query($dbconn, $update1) or die ("Error: " . mysqli_error($dbconn));
	  if ($result && $result1) {
	  ?>
	  <script type="text/javascript">
	   window.location = "update_view_schedule.php"
	  </script>
	  <?php }       
				}
?>