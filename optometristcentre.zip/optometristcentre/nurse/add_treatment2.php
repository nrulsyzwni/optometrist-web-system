<!DOCTYPE html>
<?php 
include('../include/dbconn.php');

include ("../login/session.php");
session_start();

if (!isset($_SESSION['username'])) {
        header('Location: ../login');
		} 
                $sql= "SELECT * from userdata ud, schedule s,appointment a  
				WHERE a.user_ID=ud.user_ID AND  s.appID=a.appID AND ud.IdLevel='3'";
				$query = mysqli_query($dbconn, $sql) or die ("Error: " . mysqli_error());
				$row = mysqli_num_rows($query);
				//$row= mysqli_fetch_assoc($query);
				
				date_default_timezone_set("Asia/Kuala_Lumpur");
                $date = date("d/m/Y");
                $time = date("H:i:s");
				

?>

<head>
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=Edge">
     <meta name="description" content="">
     <meta name="keywords" content="">
     <meta name="author" content="Tooplate">
     <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- <link rel="stylesheet" href="css/bootstrap.min.css">
     <link rel="stylesheet" href="css/magnific-popup.css">

     <link rel="stylesheet" href="css/font-awesome.min.css">
     <link rel="stylesheet" href="css/animate.css">

     <link rel="stylesheet" href="css/owl.carousel.css">
     <link rel="stylesheet" href="css/owl.theme.default.min.css">

     <!-- MAIN CSS 
		<link rel="stylesheet" href="css/tooplate-style.css">-->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<style>
		body 
		{
			font-family: Arial, Helvetica, sans-serif;
			margin:0;
			background-color:DarkSeaGreen;
		}
		
		row
		{
			margin-right:15px;
			margin-left:15px;
		}
		
		.container
		{
			padding-right:15px;
			padding-left:15px;
			margin-right:auto;
			margin-left:auto;
			display:inline-block;
		}
		
		@media (min-width:768px){
		.container{
			width:750px}
			}@media (min-width:992px){
				.container{
					width:970px
					}
					}@media (min-width:1200px){
						.container
						{width:1170px
						}}
							
		.col-md-8 .col-sm-7 
		{
			 width:20%;
			 position:relative;
			 min-height:1px;
			 padding-right:15px;
			 padding-left:15px
		}
		
		 text-right
		 {
			 text-align:50px;
			 padding-right:50px;
			 padding-left:100px;
			 display:inline-block;
		 }
		 
		 header 
		{
			background: #ffffff;
			border-bottom: 1px solid #f2f2f2;
			display: block;
			height: 40px;
		}
		
	header p,
	header span {
    font-size: 12px;
    line-height: 10px;
    padding-top: 0px;
	padding-left:15px;
	padding-right:400px;
	display:inline-block;
  }
.p 
{
	font-size:16px;
	width:100%;
	padding-left:505px;
	padding-right:190px;
}

  header a,
  header span {
    color: #747474;
  }

  header span {
    font-weight: 500;
    display: inline-block;
    padding: 15px;

  }

  header span.date-icon {
    border-left: 1px solid #f2f2f2;
    border-right: 1px solid #f2f2f2;
    padding-right: 15px;
    padding-left: 15px;
	
  }

  header span i {
    color: #a5c422;
    margin-right: 15px;
  }
  
		.navbar {
  overflow: hidden;
  background-color: white;
  
}

.navbar a {
  float: left;
  font-size: 16px;
  color: black;
  text-align: center;
  padding: 10px 16px;
  text-decoration: none;
}

.dropdown {
  float: left;
  overflow: hidden;
}

.dropdown .dropbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: ;
  padding: 10px 15px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.navbar a:hover, .dropdown:hover .dropbtn {
  background-color: white;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 100px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: black;
  padding: 12px 15px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  background-color: white;
}

.dropdown:hover .dropdown-content {
  display: block;
}
textarea {
  resize: none;
}
</style>
	</head>
	<body>
	<body id="top" data-spy="scroll" data-target=".navbar-collapse" data-offset="50">
     <!-- HEADER -->
     <header>
          <div class="container">
               <div class="row">					
					<div class="col-md-8 col-sm-7 text-align-right">
						<p class=="p">Welcome to eye specialist</p>
                         <span class="phone-icon"><i class="fa fa-phone"></i> 010-060-0160</span>
                         <span class="date-icon"><i class="fa fa-calendar-plus-o"></i> 6:00 AM - 10:00 PM (Mon-Fri)</span>
                         <span class="email-icon"><i class="fa fa-envelope-o"></i> <a href="#">ikonikeyespecialist@company.com</a></span>
                    </div>
               </div>
          </div>
     </header>
	 
	  <!-- MENU -->
     <section class="navbar" >
          <div class="container">

               <div class="navbar-header"
	 
                    <!-- lOGO TEXT HERE -->
                    <a href="index.html" class="navbar-brand">EYE SPECIAlIST CENTRE</a>
               </div>

               <!-- MENU LINKS -->
               <div class="collapse navbar-collapse">
                   <div class="navbar">
						<a href="#home">HOME</a>
						
						<div class="dropdown">
						<button class="dropbtn">USERS
						<i class="fa fa-caret-down"></i>
						</button>
						<div class="dropdown-content">
						<a href="../nurse/view_user.php">VIEW</a>
						<a href="update_view_user.php">UPDATE</a>
						<a href="search_patient.php">SEARCH PATIENT</a>
					</div>
				  </div> 
				  
						<div class="dropdown">
						<button class="dropbtn">SCHEDULE 
						<i class="fa fa-caret-down"></i>
						</button>
						<div class="dropdown-content">
						<a href="view_schedule.php">VIEW</a>
						<a href="update_view_schedule.php">UPDATE</a>
						<a href="add_schedule.php">ADD</a>
					</div>
				  </div> 
				  
				  <div class="dropdown">
						<button class="dropbtn">APPOINTMENT
						<i class="fa fa-caret-down"></i>
						</button>
						<div class="dropdown-content">
						<a href="view_appointment.php">VIEW</a>
						<a href="update_view_appointment.php">UPDATE</a>
						<a href="add_appointment.php">ADD</a>
					</div>
				  </div> 
				
				  
				   
				  <div class="dropdown">
						<button class="dropbtn">TREATMENT
						<i class="fa fa-caret-down"></i>
						</button>
						<div class="dropdown-content">
						<a href="view_treatment2.php">VIEW</a>
						<a href="update_view_treatment2.php">UPDATE</a>
						<a href="add_treatment2.php">ADD</a>
					</div>
				  </div> 
				  
				  <div class="dropdown">
						<button class="dropbtn">MEDICINE
						<i class="fa fa-caret-down"></i>
						</button>
						<div class="dropdown-content">
						<a href="view_medicine.php">VIEW</a>
						<a href="update_view_medicine.php">UPDATE</a>
						<a href="add_medicine.php">ADD</a>
					</div>
				  </div> 
				  
				  
				  <div class="dropdown">
						<button class="dropbtn">REPORT
						<i class="fa fa-caret-down"></i>
						</button>
						<div class="dropdown-content">
						<a href="report_user.php">REPORT USER</a>
					</div>
				  </div> 
				  
				  <a href="../login/logout.php">LOGOUT</a>
				</div>

               </div>

          </div>
     </section>

		<script type = "text/javascript">
		function calc() 
		{
		var total = 0;
		var rowNo = order.elements["bil"].value;
		var qMedicine = "quantity";
		var pMedicine ="medicinePrice";

		for (a=0;a<rowNo;a++)
		{
			var textRow = a.toString();
			var textQuantity = qMedicine + textRow;
			var textPrice = pMedicine + textRow;
			var quantity = parseInt(order.elements[textQuantity].value)
			var pPrice = parseInt(order.elements[textPrice].value);
			total = total + (quantity * pPrice);
		}
		document.getElementById("price").value = total;
		document.getElementById("cash").min = total;
		}

		</script>
		<body>
		<div class="container">

<h3>Add Patient Bill</h3>

<fieldset>

<form name="order" method="POST"  action="db_add_bill_receipt.php" enctype="multipart/form-data" >
    <table width="100%" border="0" align="center">
      <tr>
        <td width="">Patient Name</td>  
        <td width="">
			<select name="patient" style="min-width:330px;">
				<?php
					while($row= mysqli_fetch_assoc($query)){
						$patient_name = $row['name'];
						//$user_ID = $row['appID'];
						$user_ID = $row['scheduleID'];
						echo"<option value='$user_ID'>$patient_name</option>";?>
						
				<?php
					}
				?>
				
			</select>
			
		</td>  
      </tr> 
<tr>	  
      <td>Description</td>
        <td><textarea name="notice" cols="47" rows="3"></textarea></td>
 </tr>
			<?php
				$sql= "SELECT * FROM medicine ORDER BY medicineID,description , price";
				$query = mysqli_query($dbconn, $sql) or die ("Error: " . mysqli_error());
				$row = mysqli_num_rows($query);
				//$r= mysqli_fetch_assoc($query);
	
                echo "<table border='1' width='100%'  align='center'>";
                echo "<tr>
                        <td width='5%'>Code</td>
                        <td width='40%'>Medicine Name</td>
                        <td width='5%'>Price</td>
                        <td width='25%'>Quantity</td>
                        </tr>";  
						
				$strTid ="Tid";
                $strMid = "Mid";
                $strMname = "Mname";			
                $strQuantity = "quantity";	
                $strPrice = "medicinePrice";
                $strTotal = "total";	
                $no=0; 	
                
                echo "<input type='text' name='bil' id='bil' value=".$row." hidden>";
                	
												
                while ($r = mysqli_fetch_assoc($query))   
                {
					$MedicineName = $r['medicineName'];
					$medicinePrice = $r['price'];
					$Mid = $r['medicineID'];
					
					
						echo "<tr>
								<td><center><input type='hidden' class='center' name=".$strMid.$no." id=".$strMid.$no." value =".$r['medicineID'].">".$r['medicineID']."</td>
								<td>".$r['medicineName']."</td>
								<td><center><input type='hidden' class='center' name=".$strPrice.$no." id=".$strPrice.$no." value =".$r['price']." readonly'>".$r['price']."</td>
								<td><center><input type='number' name=".$strQuantity.$no." id=".$strQuantity.$no." min='0' max='100' value='0'></td>
								";
								
								
						$no++;
					}
					
					
				
                
                
                
                echo "<tr>
                        <td colspan='2'>&nbsp;</td>
                        <td>
                        <input type='button' name='calculate' id='calculate' onClick='calc()' value='Calculate'></td>
                        <td><input type='text' name='price' id='price' value='0'></td>
                        </tr>
                        <tr>
                        <td colspan='2'>&nbsp;</td>
                        <td><input type='submit' name='submit' id='submit' value='Submit'></td>
						<td><input type='number' name='cash' id='cash' value='0' min='1'></td>
                        </tr>
                        <tr>
                        <td align='center' colspan='4'>
                            <input type='reset' name='reset' id='reset' value='   Reset   ' />	
                        </td>
                        </tr>
                    ";
                echo "</table>";
                
				
                ?>
				
      
    </table>
</form>

</fieldset>
 
</div>
   
</body>

</html> 
				