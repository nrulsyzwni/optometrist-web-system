<?php 
include('../include/dbconn.php');

$i=0;

foreach ( $_POST as $sForm => $value )
{
	$postedValue = htmlspecialchars( stripslashes( $value ), ENT_QUOTES ) ;
    $valuearr[$i] = $postedValue; 
$i++;
}


$addrecord = "INSERT INTO medicine ( medicineName,description, price) 
			  VALUES('$valuearr[0]', '$valuearr[1]','$valuearr[2]')";
//echo $addrecord;
	  $result = mysqli_query($dbconn, $addrecord) or die ("Error: " . mysqli_error($dbconn));

if ($result) {
?>
<script type="text/javascript">
	window.location = "view_medicine.php"
</script>
?>
<?php } ?>
	 