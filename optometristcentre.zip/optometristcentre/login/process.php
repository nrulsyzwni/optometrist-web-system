<?php
// Inialize session
session_start();

// Include database connection settings
include('../include/dbconn.php');

if(isset($_POST['login'])){
	
	/* capture values from HTML form */
	$username = $_POST['username'];
	$password = $_POST['password'];
	
	echo $username;
	echo $password;
	
	$sql= "SELECT username, password , IdLevel FROM userdata WHERE username= '$username' AND password= '$password'";
	$query = mysqli_query($dbconn, $sql) or die ("Error: " . mysqli_error());
	$row = mysqli_num_rows($query); 
	
	echo $sql;
	echo $row;
	
	
	if($row == 0){
	 // Jump to indexwrong page
	header('Location: loginwrong.html'); 
	}
	else{
	 $r = mysqli_fetch_assoc($query);
	 $username= $r['username'];
	 //$password= $r['password'];
	 $level= $r['IdLevel'];
	 echo($level);
	 echo($username);
	
		if($level==1) { 
			$_SESSION['username'] = $r['username'];
			// Jump to secured page
			header('Location: ../nurse/index.php'); 
		} 
		elseif($level==2) {
			$_SESSION['username'] = $r['username'];
			// Jump to secured page
			header('Location: ../doctors/index.php');
		}
		elseif($level==3) {
			$_SESSION['username'] = $r['username'];
			// Jump to secured page
			header('Location: ../patients/index.php');
		}
		else {
			header('Location: index.html');
			//echo($level);
		}
		
	}
}
mysqli_close($dbconn);
?>