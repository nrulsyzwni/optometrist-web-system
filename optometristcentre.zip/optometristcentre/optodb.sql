-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 29, 2021 at 08:07 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `optodb`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `appID` int(10) NOT NULL,
  `user_ID` int(10) NOT NULL,
  `dateMade` date NOT NULL,
  `dateApp` date NOT NULL,
  `status` varchar(50) NOT NULL,
  `times` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`appID`, `user_ID`, `dateMade`, `dateApp`, `status`, `times`) VALUES
(2, 24, '2021-07-22', '2021-08-04', 'verified', '21:00:00'),
(3, 28, '0000-00-00', '0000-00-00', '', '00:00:00'),
(4, 0, '2021-07-30', '2021-08-20', '', '12:00:00'),
(89, 23, '2021-07-26', '2021-08-09', '', '15:10:00'),
(90, 23, '2021-07-29', '2021-09-10', '', '12:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `level`
--

CREATE TABLE `level` (
  `IdLevel` int(10) NOT NULL,
  `level_des` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `level`
--

INSERT INTO `level` (`IdLevel`, `level_des`) VALUES
(1, 'nurse'),
(2, 'doctors'),
(3, 'patient');

-- --------------------------------------------------------

--
-- Table structure for table `medicine`
--

CREATE TABLE `medicine` (
  `medicineID` int(10) NOT NULL,
  `medicineName` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `price` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `medicine`
--

INSERT INTO `medicine` (`medicineID`, `medicineName`, `description`, `price`) VALUES
(1, 'checkup mata', 'regular checkup for patient', '50'),
(2, 'Xepanicol Eye Drops 0.5% (5ml) ', 'packaging : Bottle', '5.50'),
(3, 'Colircusi Gentadexa (Eye/Ear Drops) (10ml)/', 'packaging: Bottle', '7.00'),
(5, 'Oftalmolosa Cusi Erythromycin 0.5% Eye Ointment(5g)', 'packaging: tube', '7.00'),
(6, 'Optizoline Eye Drops (5ml)', 'packaging:bottle', '9.30'),
(7, 'Maxitrol Sterile Ophthalmic Ointment (3.5g)/', 'packaging:tube', '13.90'),
(8, 'Tobradex Eye Ointment (3.5g)', 'packaging:tube', '2.35'),
(9, 'Vigamox® 0.5% Eye Drop(5ml) ', 'packaging:bottle', '26.90'),
(10, 'Maxidex Ophthalmic Suspension (5ml)', 'packaging: bottle', '8.45');

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `scheduleID` int(10) NOT NULL,
  `appID` int(10) NOT NULL,
  `doctorID` int(11) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`scheduleID`, `appID`, `doctorID`, `date`, `time`) VALUES
(1, 1, 3, '2021-07-29', '13:20:00'),
(2, 2, 3, '2021-07-29', '13:20:00'),
(4, 6, 25, '2021-07-29', '12:40:00');

-- --------------------------------------------------------

--
-- Table structure for table `treatment`
--

CREATE TABLE `treatment` (
  `treatmentID` int(10) NOT NULL,
  `scheduleID` int(10) NOT NULL,
  `notice` varchar(100) NOT NULL,
  `treatmentStatus` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `treatment`
--

INSERT INTO `treatment` (`treatmentID`, `scheduleID`, `notice`, `treatmentStatus`) VALUES
(1, 1, 'already finish the treatment', 'complete'),
(2, 2, 'already finish the treatment', 'complete'),
(3, 3, 'please come again for the next appointmnet', 'complete'),
(5, 2, 'come again', 'complete'),
(7, 3, 'come again', 'ongoing'),
(9, 2, 'come again', 'ongoing'),
(10, 3, 'need to put eye 2 drop for every 3 hour', 'ongoing'),
(11, 4, 'come again in next appointment', 'complete'),
(12, 1, '', 'ongoing');

-- --------------------------------------------------------

--
-- Table structure for table `treatment_medicine`
--

CREATE TABLE `treatment_medicine` (
  `treat_medID` int(10) NOT NULL,
  `treatmentID` int(10) NOT NULL,
  `medicineID` int(10) NOT NULL,
  `qty` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `treatment_medicine`
--

INSERT INTO `treatment_medicine` (`treat_medID`, `treatmentID`, `medicineID`, `qty`) VALUES
(1, 1, 2, 1),
(2, 2, 2, 1),
(3, 3, 1, 1),
(4, 4, 2, 1),
(5, 5, 1, 1),
(6, 6, 1, 1),
(7, 3, 1, 1),
(8, 5, 1, 1),
(9, 7, 1, 1),
(10, 7, 1, 1),
(13, 9, 1, 1),
(14, 10, 2, 1),
(15, 11, 1, 1),
(16, 12, 1, 1),
(17, 12, 2, 1),
(18, 12, 3, 1),
(19, 12, 5, 1),
(20, 12, 6, 1),
(21, 12, 7, 1),
(22, 12, 8, 1),
(23, 12, 9, 1),
(24, 12, 10, 1);

-- --------------------------------------------------------

--
-- Table structure for table `userdata`
--

CREATE TABLE `userdata` (
  `user_ID` int(10) NOT NULL,
  `username` varchar(20) CHARACTER SET latin1 NOT NULL,
  `password` varchar(10) CHARACTER SET latin1 NOT NULL,
  `gender` int(2) NOT NULL,
  `name` varchar(50) CHARACTER SET latin1 NOT NULL,
  `address` varchar(100) CHARACTER SET latin1 NOT NULL,
  `telephone` varchar(11) CHARACTER SET latin1 NOT NULL,
  `email` varchar(50) CHARACTER SET latin1 NOT NULL,
  `IdLevel` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `userdata`
--

INSERT INTO `userdata` (`user_ID`, `username`, `password`, `gender`, `name`, `address`, `telephone`, `email`, `IdLevel`) VALUES
(1, 'nurse', '123', 2, 'Nurse', 'Padang Serai', '0124759564', 'nurse123@gmail.com', 1),
(2, 'nurul', '1234', 2, 'Nurul', 'padang serai', '0124489564', 'nurul@gmail.com', 2),
(3, 'siti', '122', 2, 'Siti Nur', 'Kulim', '0178967456', 'siti@gmail.com', 2),
(4, 'uda', '123', 1, 'Uda', 'Perak', '0124377564', 'uda@gmail.com', 3),
(5, 'syahmi', '12', 1, 'syahmi', 'marang', '01131352030', 'safwansyahmi115@gmail.com', 3),
(23, 'safrah', '1234', 2, 'safrah', 'padang serai', '0124489564', 'safrah@gmail.com', 3),
(24, 'wani', '12345', 2, 'Wani', 'Kulim', '0124567563', 'wani123@gmail.com', 3),
(25, 'syazwani', '123', 2, 'syazwani', 'keladi', '0124679067', 'syazwani@gmail.com', 2),
(26, 'syafiq', 'syafiq123', 1, 'Syafiq', 'tikam batu', '01456789500', 'syafiq123@gmail.com', 2),
(27, 'tina', '1234', 2, 'tina', 'tikam batu', '01134352030', 'tina12@gmail.com', 2),
(28, 'adam', '1234', 1, 'adam', 'tikam batu', '01123456789', 'adam123@gmail.com', 3),
(29, 'ridzuan', 'rid123', 1, 'ridzuan', 'kulim', '12344567899', 'ridzuan123@gmail.com', 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`appID`);

--
-- Indexes for table `level`
--
ALTER TABLE `level`
  ADD PRIMARY KEY (`IdLevel`);

--
-- Indexes for table `medicine`
--
ALTER TABLE `medicine`
  ADD PRIMARY KEY (`medicineID`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`scheduleID`);

--
-- Indexes for table `treatment`
--
ALTER TABLE `treatment`
  ADD PRIMARY KEY (`treatmentID`);

--
-- Indexes for table `treatment_medicine`
--
ALTER TABLE `treatment_medicine`
  ADD PRIMARY KEY (`treat_medID`);

--
-- Indexes for table `userdata`
--
ALTER TABLE `userdata`
  ADD PRIMARY KEY (`user_ID`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `appID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;

--
-- AUTO_INCREMENT for table `level`
--
ALTER TABLE `level`
  MODIFY `IdLevel` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `medicine`
--
ALTER TABLE `medicine`
  MODIFY `medicineID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `scheduleID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `treatment`
--
ALTER TABLE `treatment`
  MODIFY `treatmentID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=344;

--
-- AUTO_INCREMENT for table `treatment_medicine`
--
ALTER TABLE `treatment_medicine`
  MODIFY `treat_medID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `userdata`
--
ALTER TABLE `userdata`
  MODIFY `user_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
